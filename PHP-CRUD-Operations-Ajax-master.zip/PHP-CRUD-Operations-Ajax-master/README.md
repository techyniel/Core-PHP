# PHP-CRUD-Operations-Ajax
Add, Edit, Delete &amp; Searching Records Using jQuery, Ajax, PHP And MySQL || PHP CRUD Operations Without Page Refresh

##How To Use/Run This Code :-
1. Download Project and Extract Files
2. Install XAMPP OR WAMP Web Server on Your System
3. XAMPP - Move ajax Folder On " c:/xampp/htdocs/ " Or WAMP - Move Your Files On " c:/wamp/www/ "
3. Open Your Web Browser And Type "localhost/phpmyadmin" Or "127.0.0.1/phpmyadmin"
4. Then Click import Button & import Database (ajax.sql)
5. Open Your Web Browser And Type "localhost/ajax/index.php" or "127.0.0.1/ajax/index.php"
6. Enjoy  ☺☺☺☺

Watch On Youtube :- https://youtu.be/el5mnLdPG1o

![a1](https://user-images.githubusercontent.com/26626045/52166024-09681000-26bd-11e9-8ad9-4da8b5cf3b43.jpg)

![123](https://user-images.githubusercontent.com/26626045/52166310-729d5280-26c0-11e9-9907-c75226c35cf0.PNG)
